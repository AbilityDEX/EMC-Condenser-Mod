# Implementation notes / next development milestone

This archive is a project scaffold, not yet the fully implemented gameplay mod. The first next step is to verify the 26.2 Minecraft classes and Fabric Loader/Loom setup by compiling against the user's exact installation.

The functional implementation should then add:

1. A server-side scan/tick strategy that only inspects loaded chunks and avoids scanning the whole world every tick.
2. Detection of a chest and an item frame attached to the chest's face.
3. A persistent per-chest EMC balance keyed by dimension and block position.
4. A configurable EMC registry, with safe handling of unknown items.
5. Transaction-safe input removal and output insertion.
6. Guards against counting output items as input repeatedly, consuming the framed target, or consuming items when no EMC value is defined.
7. Permission/ownership policy and commands to inspect/reset a condenser.
8. Geyser/Floodgate testing for item-frame and chest interaction behaviour.

Important: the first pass deliberately does not register a guessed mixin injection point. Minecraft 26.2 has recent internal API changes and a guessed hook can prevent a dedicated server from starting. After the build is confirmed, implement the tick hook using the actual mapped signatures from the resolved 26.2 artifacts.
