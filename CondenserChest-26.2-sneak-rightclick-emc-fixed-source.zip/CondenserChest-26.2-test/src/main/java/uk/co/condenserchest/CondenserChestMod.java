package uk.co.condenserchest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.server.level.ServerPlayer;
import java.util.UUID;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.core.registries.BuiltInRegistries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

public final class CondenserChestMod implements ModInitializer {
    public static final String MOD_ID = "condenser_chest";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type LONG_MAP_TYPE = new TypeToken<Map<String, Long>>() {}.getType();
    private static final Map<String, Long> emcValues = new HashMap<>();
    private static final Map<String, Long> storedEmc = new HashMap<>();
    private static final Set<String> restrictedOutputIds = new HashSet<>();
    private static Path configFile;
    private static Path saveFile;
    private static long ticks;

    @Override
    public void onInitialize() {
        loadEmcValues();
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            loadOutputConfig(server);
            int defaultItems = addDefaultsForAllItems();
            LOGGER.info("Loaded {} EMC values and assigned default EMC to {} additional items", emcValues.size(), defaultItems);
            loadStoredEmc(server);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> saveStoredEmc());
        // EMC is shown only on an intentional sneak + right-click interaction.
        // The clicked hand's item is inspected; the action-bar message is server-side.
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.isClientSide() && player.isShiftKeyDown() && player instanceof ServerPlayer serverPlayer) {
                showHeldEmc(serverPlayer, player.getItemInHand(hand));
            }
            return InteractionResult.PASS;
        });
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!world.isClientSide() && player.isShiftKeyDown() && player instanceof ServerPlayer serverPlayer) {
                showHeldEmc(serverPlayer, player.getItemInHand(hand));
            }
            return InteractionResult.PASS;
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++ticks % 20 != 0) return;
            for (ServerLevel level : server.getAllLevels()) {
                // Only entities in loaded chunks are returned by the level's entity lookup.
                for (ItemFrame frame : level.getEntities(
                        EntityTypeTest.forClass(ItemFrame.class),
                        entity -> entity.isAlive() && !entity.getItem().isEmpty())) {
                    processFrame(level, frame);
                }
            }
            saveStoredEmc();
        });
        LOGGER.info("Condenser Chest loaded: server-side item-frame condenser enabled.");
    }


    // Show the EMC value of the item in the clicked hand, but only when sneaking
    // and right-clicking. This deliberately does not affect EMC conversion rules.
    private static void showHeldEmc(ServerPlayer player, ItemStack stack) {
        if (stack.isEmpty()) {
            player.sendSystemMessage(Component.literal("Hold an item to check its EMC value."), true);
            return;
        }
        String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        long emc = valueOf(stack.getItem());
        if (emc <= 0) {
            player.sendSystemMessage(Component.literal("EMC: No value"), true);
            return;
        }
        String displayName = stack.getHoverName().getString();
        player.sendSystemMessage(Component.literal(displayName + "  |  EMC: " + emc), true);
    }

    private static void processFrame(ServerLevel level, ItemFrame frame) {
        ItemStack target = frame.getItem();
        // Valuable progression items may be placed in the frame as a target, but
        // the condenser must never create them. Their EMC can still be extracted
        // when they are input materials for producing other, permitted items.
        if (isRestrictedOutput(target.getItem())) return;
        long targetValue = valueOf(target.getItem());
        if (targetValue <= 0) return;

        // Normally the chest is directly behind the face-mounted item frame. Some
        // versions/API mappings expose the frame direction differently, so try that
        // position first and then all six adjacent blocks as a safe fallback.
        BlockPos framePos = frame.blockPosition();
        BlockPos chestPos = framePos.relative(frame.getDirection().getOpposite());
        ChestBlockEntity chest = getChestAt(level, chestPos);
        if (chest == null) {
            for (Direction direction : Direction.values()) {
                BlockPos candidate = framePos.relative(direction);
                chest = getChestAt(level, candidate);
                if (chest != null) {
                    chestPos = candidate;
                    break;
                }
            }
        }
        if (chest == null) return;

        String key = level.dimension().identifier() + ":" + chestPos.getX() + "," + chestPos.getY() + "," + chestPos.getZ();
        long balance = storedEmc.getOrDefault(key, 0L);
        boolean changed = false;

        // Never consume input items when the chest has no room for the selected output.
        // Only consume enough EMC to produce up to the available output capacity.
        int outputRoom = countOutputSpace(chest, target.getItem());
        if (outputRoom <= 0) return;

        long maximumUsefulBalance;
        if (targetValue > Long.MAX_VALUE / outputRoom) {
            maximumUsefulBalance = Long.MAX_VALUE;
        } else {
            maximumUsefulBalance = targetValue * outputRoom;
        }

        // Existing EMC is spent first. Inputs are consumed only while more EMC is
        // needed to fill the output space, leaving surplus materials in the chest.
        for (int slot = 0; slot < chest.getContainerSize() && balance < maximumUsefulBalance; slot++) {
            ItemStack stack = chest.getItem(slot);
            if (stack.isEmpty() || stack.is(target.getItem())) continue;
            long value = valueOf(stack.getItem());
            if (value <= 0) continue;

            long needed = maximumUsefulBalance - balance;
            long consumeNeeded = ((needed - 1) / value) + 1;
            int consume = (int) Math.min((long) stack.getCount(), consumeNeeded);
            if (consume <= 0) continue;

            balance += consume * value;
            stack.shrink(consume);
            if (stack.isEmpty()) chest.setItem(slot, ItemStack.EMPTY);
            changed = true;
        }

        if (balance >= targetValue) {
            int room = countOutputSpace(chest, target.getItem());
            long affordable = balance / targetValue;
            int produce = (int) Math.min((long) room, affordable);
            if (produce > 0) {
                int remaining = produce;
                for (int slot = 0; slot < chest.getContainerSize() && remaining > 0; slot++) {
                    ItemStack stack = chest.getItem(slot);
                    if (stack.isEmpty()) {
                        int add = Math.min(remaining, target.getMaxStackSize());
                        chest.setItem(slot, new ItemStack(target.getItem(), add));
                        remaining -= add;
                    } else if (ItemStack.isSameItemSameComponents(stack, target) && stack.getCount() < stack.getMaxStackSize()) {
                        int add = Math.min(remaining, stack.getMaxStackSize() - stack.getCount());
                        stack.grow(add);
                        remaining -= add;
                    }
                }
                int actuallyProduced = produce - remaining;
                balance -= (long) actuallyProduced * targetValue;
                changed = changed || actuallyProduced > 0;
            }
        }

        if (changed) {
            storedEmc.put(key, balance);
            chest.setChanged();
        }
    }


    private static ChestBlockEntity getChestAt(ServerLevel level, BlockPos pos) {
        // The condenser intentionally supports single chests only. A double chest
        // has LEFT/RIGHT chest type and must not be processed by either half.
        var state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof ChestBlock)) return null;
        if (state.getValue(ChestBlock.TYPE) != ChestType.SINGLE) return null;

        BlockEntity blockEntity = level.getBlockEntity(pos);
        return blockEntity instanceof ChestBlockEntity chest ? chest : null;
    }

    private static int countOutputSpace(ChestBlockEntity chest, Item item) {
        long room = 0;
        for (int slot = 0; slot < chest.getContainerSize(); slot++) {
            ItemStack stack = chest.getItem(slot);
            if (stack.isEmpty()) room += item.getDefaultMaxStackSize();
            else if (stack.is(item)) room += Math.max(0, stack.getMaxStackSize() - stack.getCount());
        }
        return (int) Math.min(Integer.MAX_VALUE, room);
    }

    // Items with durability (weapons, tools, armour, and similar gear) are
    // excluded from EMC entirely, even if they appear in the curated JSON.
    // All non-durable registered items receive a default value of 1 unless curated.
    private static int addDefaultsForAllItems() {
        int added = 0;
        for (Item item : BuiltInRegistries.ITEM) {
            String id = BuiltInRegistries.ITEM.getKey(item).toString();
            if (item.components().has(DataComponents.MAX_DAMAGE)) {
                emcValues.remove(id);
                continue;
            }
            if (!emcValues.containsKey(id)) {
                emcValues.put(id, 1L);
                added++;
            }
        }
        return added;
    }


    /**
     * Items that may contribute EMC as inputs but may not be produced as outputs.
     * This deliberately uses registry IDs so it covers vanilla ore variants and
     * block forms without depending on language/display names.
     */
    private static boolean isDefaultRestrictedOutput(Item item) {
        String path = BuiltInRegistries.ITEM.getKey(item).getPath();

        // All vanilla ore blocks, including deepslate and Nether variants.
        if (path.endsWith("_ore")) return true;

        // All copper block families, including cut, exposed, weathered, oxidized,
        // waxed, chiseled, grate, bulb, door, trapdoor and decorative variants.
        if (path.contains("copper") && (path.endsWith("_block") || path.contains("copper_block")
                || path.startsWith("cut_copper") || path.contains("copper_bulb")
                || path.contains("copper_grate") || path.contains("copper_door")
                || path.contains("copper_trapdoor") || path.contains("copper_chest")
                || path.contains("copper_golem_statue"))) return true;

        // Raw ore materials and compacted block forms.
        if (path.equals("raw_iron") || path.equals("raw_copper") || path.equals("raw_gold")
                || path.equals("raw_iron_block") || path.equals("raw_copper_block") || path.equals("raw_gold_block")) return true;

        // Valuable minerals and all their specified block forms.
        if (path.equals("diamond") || path.equals("diamond_block")
                || path.equals("emerald") || path.equals("emerald_block")
                || path.equals("iron_ingot") || path.equals("iron_block") || path.equals("iron_nugget")
                || path.equals("gold_ingot") || path.equals("gold_block") || path.equals("gold_nugget")
                || path.equals("netherite_ingot") || path.equals("netherite_block") || path.equals("netherite_scrap")
                || path.equals("ancient_debris")
                || path.equals("copper_ingot") || path.equals("raw_copper")
                || path.equals("coal") || path.equals("charcoal") || path.equals("coal_block")
                || path.equals("lapis_lazuli") || path.equals("lapis_block")
                || path.equals("redstone") || path.equals("redstone_block")
                || path.equals("quartz") || path.equals("quartz_block") || path.equals("smooth_quartz")
                || path.equals("amethyst_shard") || path.equals("amethyst_block")
                || path.equals("budding_amethyst") || path.equals("small_amethyst_bud")
                || path.equals("medium_amethyst_bud") || path.equals("large_amethyst_bud")
                || path.equals("amethyst_cluster") || path.equals("prismarine_shard")
                || path.equals("prismarine_crystals")) return true;

        // Boss drops, rare equipment, progression loot and structure rewards.
        if (path.equals("nether_star") || path.equals("dragon_egg") || path.equals("dragon_breath")
                || path.equals("wither_skeleton_skull") || path.equals("dragon_head")
                || path.equals("elytra") || path.equals("totem_of_undying") || path.equals("trident")
                || path.equals("mace") || path.equals("heavy_core")
                || path.equals("netherite_upgrade_smithing_template")
                || path.endsWith("_smithing_template")
                || path.equals("enchanted_golden_apple") || path.equals("golden_apple")
                || path.equals("heart_of_the_sea") || path.equals("echo_shard")
                || path.equals("nautilus_shell") || path.endsWith("_music_disc")
                || path.equals("trial_key") || path.equals("ominous_trial_key")
                || path.equals("shulker_shell") || path.endsWith("_shulker_box")
                || path.equals("sponge") || path.equals("wet_sponge")
                || path.equals("beacon") || path.equals("conduit") || path.equals("end_crystal")
                || path.equals("respawn_anchor") || path.equals("experience_bottle")
                || path.equals("enchanted_book") || path.equals("diamond_horse_armor")
                || path.equals("pottery_sherd") || path.endsWith("_pottery_sherd")
                || path.equals("ominous_bottle") || path.equals("dragon_egg")
                || path.equals("prismarine_shard") || path.equals("prismarine_crystals")) return true;

        // Restrict all horse armour and the full pottery-shard family, rather than
        // relying on a single registry ID for each category.
        if (path.endsWith("_horse_armor") || path.endsWith("_pottery_sherd")) return true;

        return false;
    }

    /**
     * Output restrictions are configurable per world. Restricted items can still
     * be inserted as EMC ingredients; this check only blocks producing them.
     */
    private static boolean isRestrictedOutput(Item item) {
        return restrictedOutputIds.contains(BuiltInRegistries.ITEM.getKey(item).toString());
    }

    private static void loadOutputConfig(MinecraftServer server) {
        configFile = server.getWorldPath(LevelResource.ROOT).resolve("condenser-chest-config.json");
        restrictedOutputIds.clear();
        try {
            if (Files.exists(configFile)) {
                Map<String, Object> config = GSON.fromJson(Files.readString(configFile, StandardCharsets.UTF_8),
                        new TypeToken<Map<String, Object>>() {}.getType());
                Object values = config == null ? null : config.get("restricted_outputs");
                if (values instanceof java.util.List<?> list) {
                    for (Object value : list) {
                        if (value instanceof String id && id.contains(":")) {
                            restrictedOutputIds.add(id.trim());
                        }
                    }
                }
                LOGGER.info("Loaded {} configured restricted condenser outputs", restrictedOutputIds.size());
                return;
            }
        } catch (Exception e) {
            LOGGER.error("Could not read condenser output config; generating default config", e);
        }

        // Seed the editable config with the mod's existing built-in restrictions.
        for (Item item : BuiltInRegistries.ITEM) {
            if (isDefaultRestrictedOutput(item)) {
                restrictedOutputIds.add(BuiltInRegistries.ITEM.getKey(item).toString());
            }
        }
        saveOutputConfig();
        LOGGER.info("Created default condenser output config with {} restricted items", restrictedOutputIds.size());
    }

    private static void saveOutputConfig() {
        if (configFile == null) return;
        try {
            Files.createDirectories(configFile.getParent());
            Map<String, Object> config = new HashMap<>();
            config.put("_comment", "Items listed in restricted_outputs cannot be produced by the condenser, but can still be used as EMC ingredients. Use IDs such as minecraft:diamond.");
            config.put("restricted_outputs", restrictedOutputIds.stream().sorted().toList());
            Files.writeString(configFile, GSON.toJson(config), StandardCharsets.UTF_8);
        } catch (Exception e) {
            LOGGER.error("Could not write condenser output config", e);
        }
    }

    private static long valueOf(Item item) {
        Identifier id = BuiltInRegistries.ITEM.getKey(item);
        return emcValues.getOrDefault(id.toString(), 0L);
    }

    private static void loadEmcValues() {
        try (var stream = CondenserChestMod.class.getResourceAsStream("/emc-values.json")) {
            if (stream != null) {
                Map<String, Double> loaded = GSON.fromJson(new String(stream.readAllBytes(), StandardCharsets.UTF_8), new TypeToken<Map<String, Double>>() {}.getType());
                if (loaded != null) loaded.forEach((id, value) -> { if (value != null && value > 0 && value <= Long.MAX_VALUE) emcValues.put(id, value.longValue()); });
            }
        } catch (Exception e) {
            LOGGER.error("Could not load built-in EMC values", e);
        }
    }

    private static void loadStoredEmc(MinecraftServer server) {
        saveFile = server.getWorldPath(LevelResource.ROOT).resolve("condenser-chest-emc.json");
        try {
            if (Files.exists(saveFile)) {
                Map<String, Long> loaded = GSON.fromJson(Files.readString(saveFile), LONG_MAP_TYPE);
                storedEmc.clear();
                if (loaded != null) loaded.forEach((key, value) -> { if (key != null && value != null && value > 0) storedEmc.put(key, value); });
            }
            LOGGER.info("Loaded {} condenser EMC balances", storedEmc.size());
        } catch (Exception e) {
            LOGGER.error("Could not load condenser EMC data; no balances have been changed", e);
        }
    }

    private static void saveStoredEmc() {
        if (saveFile == null) return;
        try {
            Files.createDirectories(saveFile.getParent());
            Path temp = saveFile.resolveSibling(saveFile.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(storedEmc, LONG_MAP_TYPE), StandardCharsets.UTF_8);
            try {
                Files.move(temp, saveFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ignored) {
                Files.move(temp, saveFile, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            LOGGER.error("Could not save condenser EMC data", e);
        }
    }
}
