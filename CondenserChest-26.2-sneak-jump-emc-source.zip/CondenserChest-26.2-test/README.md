# Condenser Chest — Minecraft 26.2 / Fabric

Experimental server-side prototype. No client mod is required.

## Test setup
1. Install the JAR on the Fabric server only.
2. Put a vanilla item frame on a chest and place the item you want to create in the frame.
3. Put configured EMC-value items in that chest. Every second the mod converts known items into EMC and crafts as many target items as fit and are affordable.
4. EMC balances are stored in `condenser-chest-emc.json` in the server world directory.

Only items listed in `emc-values.json` are consumed. The initial values are examples and can be changed in the source before building. The current prototype does not provide a command or in-game EMC balance display. Test on a backup world first; this is an early experimental build.


## Configuring restricted condenser outputs

On the first server start, the mod creates `condenser-chest-config.json` in the
world save directory. Its `restricted_outputs` list is pre-filled using the
mod's existing default restrictions. Add or remove namespaced item IDs such as
`minecraft:diamond` to control which items the condenser may produce.

This only blocks listed items as outputs. They can still be used as EMC
ingredients. Restart the server after editing the file.


### Checking EMC values

Sneak (hold Shift) and jump to display the EMC value of the item in your main hand. Right-clicking and placing blocks do not trigger the display.
